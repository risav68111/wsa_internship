import React ,{useEffect} from 'react'
import { getRestaurants } from '../../actions/restaurantsAction';
import { useDispatch, useSelector } from 'react-redux';

function CountRestro() {
    const dispatch= useDispatch();
    const { loading, error, count, showVegOnly, PureVegRestuarantsCount }= 
        useSelector((state)=> state.restaurants);

    useEffect(()=> {
        dispatch(getRestaurants());
    }, [dispatch]);
    return (
        <div>
            { loading ? (
                <p> Loading Restaurant count ...</p>
            ) 
            : error ? (<p>Error: {error}</p>) : (
            <p className="NumOfRestro">
                {showVegOnly ? PureVegRestuarantsCount : count} {" "}
                <span className='Restro'>
                    { showVegOnly ? PureVegRestuarantsCount ===1
                    ? "Restuarant" 
                    : "Restaurants"
                    : count===1
                    ? "Restaurant"
                    : "Restaurants" }
                </span>
            </p>
            ) }
        </div>
    )
}

export default CountRestro