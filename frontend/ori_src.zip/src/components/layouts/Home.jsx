import React, { useEffect } from "react";
import CountRestro from "./CountRestro.jsx";
import Restaurant from "./Restaurant.jsx";
import { useDispatch, useSelector } from "react-redux";
import { getRestaurants, 
         sortByRatings, 
         sortByReviews, 
         toggleVegOnly } from "../../actions/restaurantsAction.js";
import Loader from "./Loader.jsx";
import Message from './Message.jsx';

function Home() {
    const dispatch= useDispatch();
    const {
        loading: restaurantsloading,
        error: restaurantsError,
        restaurants,
        showVegOnly,
    }= useSelector((state) => state.restaurants);
    
    useEffect(()=> {
        dispatch(getRestaurants());
    }, [dispatch]);

    const handleSortByReview=()=>  {
        dispatch(sortByReviews());
    }

    const handleSortByRatings=()=> {
        dispatch(sortByRatings());
    }

    const handleToogleVegOnly=()=> {
        dispatch(toggleVegOnly());
    }

    return(
        <>
            <CountRestro />
            { restaurantsloading ? <Loader /> : restaurantsError ? (<Message />): (
                
            <section className="sort">
                <button className="sort_veg p-3" onClick={handleToogleVegOnly} > 
                    { showVegOnly? "ShowAll": "Pure Veg" }</button>
                <button className="sort_rev p-3" onClick={handleSortByReview}>Sort by Review</button>
                <button className="sort_rat p-3" onClick={handleSortByRatings} >Sort by Rating</button>
                <div className="row mt-4">
                    {restaurants 
                    ? restaurants.map((restaurant) => 
                            !showVegOnly || 
                        (showVegOnly && restaurant.isVeg)? (
                        <Restaurant key={restaurant._id} restaurant= {restaurant} />
                    ): null 
                    ) : ( 
                        <message variant="info"> No Restaurant Found</message>
                    ) }
                </div>
            </section>
            ) } 
        </>
    )
}

export default Home