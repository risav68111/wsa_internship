import React from 'react'

function Footer() {
    return (
        <p className="text-center" >
            {new Date().getFullYear() } &copy; All Right Reserved 
        </p>
    )
}

export default Footer